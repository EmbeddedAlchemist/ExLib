#include "SPI.h"

uint8_t SPIClass::transfer(uint8_t data) {
    return 0;
}

uint16_t SPIClass::transfer16(uint16_t data) {
    return 0;
}

void SPIClass::transfer(void *buf, size_t count) {
}

void SPIClass::usingInterrupt(int interruptNumber) {
}

void SPIClass::notUsingInterrupt(int interruptNumber) {
}

void SPIClass::beginTransaction(arduino::SPISettings settings) {
}

void SPIClass::endTransaction(void) {
}

void SPIClass::attachInterrupt() {
}

void SPIClass::detachInterrupt() {
}

void SPIClass::begin() {
}

void SPIClass::end() {
}

void SPIClass::setClockDivider(uint32_t divider) {
}

void SPIClass::setBitOrder(uint32_t bitOrder) {
}

void SPIClass::setDataMode(uint32_t mode) {
}
