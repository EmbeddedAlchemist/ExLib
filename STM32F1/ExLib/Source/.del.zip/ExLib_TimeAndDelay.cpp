#include "ExLib_TimeAndDelay.hpp"
#include "DeviceSupport/misc.h"
#include "DeviceSupport/stm32f10x.h"
#include "DeviceSupport/system_stm32f10x.h"


volatile uint32_t Time::_millisecond_value = 0;

SecondUnit operator"" _s(unsigned long long x) {
    return {(uint32_t)x};
}

MillisecondUnit operator"" _s(long double x) {
    return {(uint32_t)(x * 1000)};
}

MillisecondUnit operator"" _ms(unsigned long long x) {
    return {(uint32_t)x};
}

MicrosecondUnit operator"" _ms(long double x) {
    return {(uint32_t)(x * 1000)};
}

MicrosecondUnit operator"" _us(unsigned long long x) {
    return {(uint32_t)x};
}

void Time::delayS(uint32_t s) {
    _delayMs(s * 1000);
}

void Time::delayMs(uint32_t ms) {
    _delayMs(ms);
}

void Time::delayUs(uint32_t us) {
    if (us < 1000) {
        _delayUs(us);
    } else {
        uint32_t nms = us / 1000;
        uint32_t nus = us % 1000;
        _delayMs(nms);
        _delayUs(nus);
    }
}

void Time::_delayMs(uint32_t ms) {
    uint32_t endTime = millisecond() + ms;
    while (millisecond() < endTime)
        ;
}

void Time::_delayUs(uint32_t us) {
}

void Time::_init() {
    SystemCoreClockUpdate();
    SysTick_Config(SystemCoreClock / 1000);          // 1ms
    SysTick_CLKSourceConfig(SysTick_CLKSource_HCLK); // 直接使用AHB时钟，即系统时钟不分频
}

uint32_t Time::millisecond(void) {
    return _millisecond_value;
}

uint32_t Time::microSecond(void) {
    return 0;
}

extern "C" {
void SysTick_Handler(void);
void SysTick_Handler(void) {
    Time::_millisecond_value++;
}
}