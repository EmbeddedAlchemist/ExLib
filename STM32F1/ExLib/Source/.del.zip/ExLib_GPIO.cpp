
#include "ExLib_GPIO.hpp"

#include "DeviceSupport/stm32f10x_adc.h"
#include "DeviceSupport/stm32f10x_gpio.h"
#include "DeviceSupport/stm32f10x_rcc.h"
// #include "ExLib_EXIT.hpp"

#ifdef EXTI
#undef EXTI
#endif

uint16_t getStdLibPin(GPIOPin pin)
{
    switch (pin) {
        case GPIOPin::PA0:
        case GPIOPin::PB0:
        case GPIOPin::PC0:
        case GPIOPin::PD0:
        case GPIOPin::PE0:
        case GPIOPin::PF0:
        case GPIOPin::PG0:
            return GPIO_Pin_0;

        case GPIOPin::PA1:
        case GPIOPin::PB1:
        case GPIOPin::PC1:
        case GPIOPin::PD1:
        case GPIOPin::PE1:
        case GPIOPin::PF1:
        case GPIOPin::PG1:
            return GPIO_Pin_1;

        case GPIOPin::PA2:
        case GPIOPin::PB2:
        case GPIOPin::PC2:
        case GPIOPin::PD2:
        case GPIOPin::PE2:
        case GPIOPin::PF2:
        case GPIOPin::PG2:
            return GPIO_Pin_2;

        case GPIOPin::PA3:
        case GPIOPin::PB3:
        case GPIOPin::PC3:
        case GPIOPin::PD3:
        case GPIOPin::PE3:
        case GPIOPin::PF3:
        case GPIOPin::PG3:
            return GPIO_Pin_3;

        case GPIOPin::PA4:
        case GPIOPin::PB4:
        case GPIOPin::PC4:
        case GPIOPin::PD4:
        case GPIOPin::PE4:
        case GPIOPin::PF4:
        case GPIOPin::PG4:
            return GPIO_Pin_4;

        case GPIOPin::PA5:
        case GPIOPin::PB5:
        case GPIOPin::PC5:
        case GPIOPin::PD5:
        case GPIOPin::PE5:
        case GPIOPin::PF5:
        case GPIOPin::PG5:
            return GPIO_Pin_5;

        case GPIOPin::PA6:
        case GPIOPin::PB6:
        case GPIOPin::PC6:
        case GPIOPin::PD6:
        case GPIOPin::PE6:
        case GPIOPin::PF6:
        case GPIOPin::PG6:
            return GPIO_Pin_6;

        case GPIOPin::PA7:
        case GPIOPin::PB7:
        case GPIOPin::PC7:
        case GPIOPin::PD7:
        case GPIOPin::PE7:
        case GPIOPin::PF7:
        case GPIOPin::PG7:
            return GPIO_Pin_7;

        case GPIOPin::PA8:
        case GPIOPin::PB8:
        case GPIOPin::PC8:
        case GPIOPin::PD8:
        case GPIOPin::PE8:
        case GPIOPin::PF8:
        case GPIOPin::PG8:
            return GPIO_Pin_8;

        case GPIOPin::PA9:
        case GPIOPin::PB9:
        case GPIOPin::PC9:
        case GPIOPin::PD9:
        case GPIOPin::PE9:
        case GPIOPin::PF9:
        case GPIOPin::PG9:
            return GPIO_Pin_9;

        case GPIOPin::PA10:
        case GPIOPin::PB10:
        case GPIOPin::PC10:
        case GPIOPin::PD10:
        case GPIOPin::PE10:
        case GPIOPin::PF10:
        case GPIOPin::PG10:
            return GPIO_Pin_10;

        case GPIOPin::PA11:
        case GPIOPin::PB11:
        case GPIOPin::PC11:
        case GPIOPin::PD11:
        case GPIOPin::PE11:
        case GPIOPin::PF11:
        case GPIOPin::PG11:
            return GPIO_Pin_11;

        case GPIOPin::PA12:
        case GPIOPin::PB12:
        case GPIOPin::PC12:
        case GPIOPin::PD12:
        case GPIOPin::PE12:
        case GPIOPin::PF12:
        case GPIOPin::PG12:
            return GPIO_Pin_12;

        case GPIOPin::PA13:
        case GPIOPin::PB13:
        case GPIOPin::PC13:
        case GPIOPin::PD13:
        case GPIOPin::PE13:
        case GPIOPin::PF13:
        case GPIOPin::PG13:
            return GPIO_Pin_13;

        case GPIOPin::PA14:
        case GPIOPin::PB14:
        case GPIOPin::PC14:
        case GPIOPin::PD14:
        case GPIOPin::PE14:
        case GPIOPin::PF14:
        case GPIOPin::PG14:
            return GPIO_Pin_14;

        case GPIOPin::PA15:
        case GPIOPin::PB15:
        case GPIOPin::PC15:
        case GPIOPin::PD15:
        case GPIOPin::PE15:
        case GPIOPin::PF15:
        case GPIOPin::PG15:
            return GPIO_Pin_15;

        default:
            throw GPIOException("Bad GPIO pin");
    }
}

void *getStdLibPort(GPIOPin pin)
{
    switch (pin) {
        case GPIOPin::PA0:
        case GPIOPin::PA1:
        case GPIOPin::PA2:
        case GPIOPin::PA3:
        case GPIOPin::PA4:
        case GPIOPin::PA5:
        case GPIOPin::PA6:
        case GPIOPin::PA7:
        case GPIOPin::PA8:
        case GPIOPin::PA9:
        case GPIOPin::PA10:
        case GPIOPin::PA11:
        case GPIOPin::PA12:
        case GPIOPin::PA13:
        case GPIOPin::PA14:
        case GPIOPin::PA15:
            return GPIOA;

        case GPIOPin::PB0:
        case GPIOPin::PB1:
        case GPIOPin::PB2:
        case GPIOPin::PB3:
        case GPIOPin::PB4:
        case GPIOPin::PB5:
        case GPIOPin::PB6:
        case GPIOPin::PB7:
        case GPIOPin::PB8:
        case GPIOPin::PB9:
        case GPIOPin::PB10:
        case GPIOPin::PB11:
        case GPIOPin::PB12:
        case GPIOPin::PB13:
        case GPIOPin::PB14:
        case GPIOPin::PB15:
            return GPIOB;

        case GPIOPin::PC0:
        case GPIOPin::PC1:
        case GPIOPin::PC2:
        case GPIOPin::PC3:
        case GPIOPin::PC4:
        case GPIOPin::PC5:
        case GPIOPin::PC6:
        case GPIOPin::PC7:
        case GPIOPin::PC8:
        case GPIOPin::PC9:
        case GPIOPin::PC10:
        case GPIOPin::PC11:
        case GPIOPin::PC12:
        case GPIOPin::PC13:
        case GPIOPin::PC14:
        case GPIOPin::PC15:
            return GPIOC;

        case GPIOPin::PD0:
        case GPIOPin::PD1:
        case GPIOPin::PD2:
        case GPIOPin::PD3:
        case GPIOPin::PD4:
        case GPIOPin::PD5:
        case GPIOPin::PD6:
        case GPIOPin::PD7:
        case GPIOPin::PD8:
        case GPIOPin::PD9:
        case GPIOPin::PD10:
        case GPIOPin::PD11:
        case GPIOPin::PD12:
        case GPIOPin::PD13:
        case GPIOPin::PD14:
        case GPIOPin::PD15:
            return GPIOD;

        case GPIOPin::PE0:
        case GPIOPin::PE1:
        case GPIOPin::PE2:
        case GPIOPin::PE3:
        case GPIOPin::PE4:
        case GPIOPin::PE5:
        case GPIOPin::PE6:
        case GPIOPin::PE7:
        case GPIOPin::PE8:
        case GPIOPin::PE9:
        case GPIOPin::PE10:
        case GPIOPin::PE11:
        case GPIOPin::PE12:
        case GPIOPin::PE13:
        case GPIOPin::PE14:
        case GPIOPin::PE15:
            return GPIOE;

        case GPIOPin::PF0:
        case GPIOPin::PF1:
        case GPIOPin::PF2:
        case GPIOPin::PF3:
        case GPIOPin::PF4:
        case GPIOPin::PF5:
        case GPIOPin::PF6:
        case GPIOPin::PF7:
        case GPIOPin::PF8:
        case GPIOPin::PF9:
        case GPIOPin::PF10:
        case GPIOPin::PF11:
        case GPIOPin::PF12:
        case GPIOPin::PF13:
        case GPIOPin::PF14:
        case GPIOPin::PF15:
            return GPIOF;

        case GPIOPin::PG0:
        case GPIOPin::PG1:
        case GPIOPin::PG2:
        case GPIOPin::PG3:
        case GPIOPin::PG4:
        case GPIOPin::PG5:
        case GPIOPin::PG6:
        case GPIOPin::PG7:
        case GPIOPin::PG8:
        case GPIOPin::PG9:
        case GPIOPin::PG10:
        case GPIOPin::PG11:
        case GPIOPin::PG12:
        case GPIOPin::PG13:
        case GPIOPin::PG14:
        case GPIOPin::PG15:
            return GPIOG;

        default:
            throw GPIOException("Bad GPIO pin");
    }
}

uint32_t getStdLibPeriphClock(GPIO_TypeDef *GPIOx)
{
    switch ((std::uintptr_t)GPIOx) {
        case GPIOA_BASE:
            return RCC_APB2Periph_GPIOA;

        case GPIOB_BASE:
            return RCC_APB2Periph_GPIOB;

        case GPIOC_BASE:
            return RCC_APB2Periph_GPIOC;

        case GPIOD_BASE:
            return RCC_APB2Periph_GPIOD;

        case GPIOE_BASE:
            return RCC_APB2Periph_GPIOE;

        case GPIOF_BASE:
            return RCC_APB2Periph_GPIOF;

        case GPIOG_BASE:
            return RCC_APB2Periph_GPIOG;

        default:
            throw GPIOException("Bad GPIO port");
    }
}

GPIOMode_TypeDef getStdLibMode(GPIOMode mode)
{
    switch (mode) {
        case GPIOMode::InputHiZ:
            return GPIO_Mode_IN_FLOATING;

        case GPIOMode::InputPullUp:
            return GPIO_Mode_IPU;

        case GPIOMode::InputPullDown:
            return GPIO_Mode_IPD;

        case GPIOMode::OutputPushPull:
            return GPIO_Mode_Out_PP;

        case GPIOMode::OutputOpenDrain:
            return GPIO_Mode_Out_OD;

        case GPIOMode::Analog:
            return GPIO_Mode_AIN;

        default:
            throw GPIOException("Bad GPIO mode");
    }
}

GPIO::GPIO(GPIOPin pin, GPIOMode mode)
{
    this->_pin    = getStdLibPin(pin);
    this->_periph = getStdLibPort(pin);
    RCC_APB2PeriphClockCmd(getStdLibPeriphClock((GPIO_TypeDef *)_periph), ENABLE);
    this->mode(mode);
}

void GPIO::mode(GPIOMode mode)
{
    GPIO_InitTypeDef initData;
    initData.GPIO_Speed = GPIO_Speed_50MHz;
    initData.GPIO_Pin   = _pin;
    initData.GPIO_Mode  = getStdLibMode(mode);
    GPIO_Init((GPIO_TypeDef *)_periph, &initData);

    if (mode == GPIOMode::Analog) {
        // TODO: ADC通道注册...
    }
}


void GPIO::write(uint8_t value)
{
    GPIO_WriteBit((GPIO_TypeDef *)_periph, _pin, (BitAction)value);
}

void ExLib::GPIO::write(bool level) {
}

uint8_t GPIO::read(void) {
    return GPIO_ReadOutputDataBit((GPIO_TypeDef *)_periph, _pin);
}

void GPIO::toggle(void)
{
    write(!GPIO_ReadOutputDataBit((GPIO_TypeDef *)_periph, _pin));
}

uint16_t GPIO::analogRead()
{
    // TODO ADC获取
    return 0;
}

void GPIO::onRaising(CallbackFunction &cb)
{
}

void GPIO::_enableAlternateFunction()
{
    RCC_APB2PeriphResetCmd(RCC_APB2Periph_AFIO, ENABLE);
}
