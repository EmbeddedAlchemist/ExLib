#include "ExLib_System.hpp"

#include "DeviceSupport/core_cm3.h"

extern "C" {
static uint32_t coreDumpMemory[18];
void _coreDump() {
    // 首先把内核寄存器的值Dump出来，为了不破坏现场，使用全局变量保存值，使用汇编读取
    // TODO dump
    __ASM("AREAglobals,CODE,READONLY");
    __ASM("IMPORT   coreDumpMemory");
    __ASM("PUSH R1");
    __ASM("LDR  R1, =coreDumpMemory");
    __ASM("STR  R4, [R1, #0]");
    __ASM("STR  R5, [R1, #4]");
    __ASM("STR  R6, [R1, #8]");
    __ASM("STR  R7, [R1, #12]");
    __ASM("STR  R8, [R1, #16]");
    __ASM("STR  R9, [R1, #20]");
    __ASM("STR  R10, [R1, #24]");
    __ASM("STR  R11, [R1, #28]");
    __ASM("STR  R12, [R1, #32]");
    __ASM("STR  R13, [R1, #36]");
    __ASM("STR  R14, [R1, #40]");
    __ASM("STR  R15, [R1, #44]");
    __ASM("POP R1");

    while (1)
        ;
}
}

void System::debugInterface(Printable *itf) {
    _debugInterface = itf;
}

void System::coreDump() {
    _coreDump();
}

void System::reset() {
    NVIC_SystemReset();
}

void System::raiseHardFaultError() {
    *((volatile uint32_t *)0) = 0;
    while (1)
        ;
}