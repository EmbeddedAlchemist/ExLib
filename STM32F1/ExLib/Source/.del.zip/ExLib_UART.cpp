#include "ExLib_UART.hpp"
#include "DeviceSupport/stm32f10x_usart.h"



USART_TypeDef *getStdLibPeriph(UARTPeriph uartx) {
    switch (uartx) {
        case (UARTPeriph)0:
            return USART1;
        case (UARTPeriph)1:
            return USART2;
        case (UARTPeriph)2:
            return USART3;
        case (UARTPeriph)3:
            return UART4;
        case (UARTPeriph)4:
            return UART5;
        default:
            throw UARTException("Bad UART periph");
    }
}


void periphClockCmd(USART_TypeDef *usartx, FunctionalState x) {
    switch ((intptr_t)usartx) {
        case USART1_BASE:
            RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1, x);
            break;
        case USART2_BASE:
            RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1, x);
            break;
        case USART3_BASE:
            RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART3, x);
            break;
        case UART4_BASE:
            RCC_APB1PeriphClockCmd(RCC_APB1Periph_UART4, x);
            break;
        case UART5_BASE:
            RCC_APB1PeriphClockCmd(RCC_APB1Periph_UART5, x);
            break;
    }
}

uint16_t getStdLibParity(UARTParity parity) {
    switch (parity) {
        case UARTParity::No:
            return USART_Parity_No;
        case UARTParity::Even:
            return USART_Parity_Even;
        case UARTParity::Odd:
            return USART_Parity_Odd;
        default:
            throw UARTException("Bad UART parity");
    }
}

UART::UART(UARTPeriph periph, size_t txBufferBlockSize, size_t rxBufferSize)
    : txBuffer(*new FIFOBuffer<char>(txBufferBlockSize)), rxBuffer(*new FIFOBuffer<char>(rxBufferSize)) {
    this->periph = getStdLibPeriph(periph);
}

UART::~UART() {
    end();
    delete &txBuffer;
    delete &rxBuffer;
}

void UART::begin(uint32_t BaudRate,
                 UARTParity parity,
                 UARTStopBits stopBits,
                 UARTWordLength wordLength) {
    periphClockCmd((USART_TypeDef *)periph, ENABLE);
    USART_InitTypeDef config;
    config.USART_BaudRate=BaudRate;
    config.USART_Mode = USART_Mode_Tx | USART_Mode_Rx;
    config.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    config.USART_Parity;
    config.USART_StopBits;
    config.USART_WordLength;
    USART_Init((USART_TypeDef *)periph, &config);
    USART_Cmd((USART_TypeDef *)periph, ENABLE);
}

void UART::end() {
    USART_Cmd((USART_TypeDef *)periph, DISABLE);
    periphClockCmd((USART_TypeDef *)periph, DISABLE);
}

extern "C" {
void USART1_IRQHandler() {
    const int a = 0;
}
}
