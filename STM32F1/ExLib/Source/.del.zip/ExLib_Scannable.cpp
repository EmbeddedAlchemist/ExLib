#include "ExLib_Scannable.hpp"

Scannable &Scannable::operator>>(long long &x) {
    x = praseInt();
    return *this;
}

Scannable &Scannable::operator>>(double &x) {
    x = praseFloat();
    return *this;
}

Scannable &Scannable::operator>>(std::string &s) {
    readLine(s);
    return *this;
}

Scannable &Scannable::operator>>(char *s) {
    readLine(s);
    return *this;
}
