#include "ExLib_EXIT.hpp"
#include "DeviceSupport/stm32f10x_exti.h"
#include "DeviceSupport/stm32f10x_gpio.h"

// 论命名空间的污染
#ifdef EXTI
#undef EXTI
#endif

static EXTICallbackFunction *EXTICallbacks = nullptr;

void EXTI::init()
{
}

void EXTI::registerCallback(EXTICallbackFunction &cb)
{
}



EXTICallbackFunction::EXTICallbackFunction(GPIO &io, EXTITrigger trigger, void (*callback)(void *), void *param)
    : io(io), trigger(trigger), CallbackFunction(callback, param), next(nullptr) {
}

void EXTICallbackFunction::callbackHandler(uint8_t GPIO_Pin_x){
    EXTICallbackFunction *thisCallback = EXTICallbacks;
    while(thisCallback){
        if(thisCallback->io._pin==GPIO_Pin_x){
            
        }
    }

}

void EXTI0_IRQHandler() {
    if (EXTI_GetITStatus(EXTI_Line0) != RESET) {
        EXTI_ClearITPendingBit(EXTI_Line0);
    }
}

void EXTI1_IRQHandler() {
    if (EXTI_GetITStatus(EXTI_Line1) != RESET) {
        EXTI_ClearITPendingBit(EXTI_Line1);
    }
}

void EXTI2_IRQHandler() {
    if (EXTI_GetITStatus(EXTI_Line2) != RESET) {
        EXTI_ClearITPendingBit(EXTI_Line2);
    }
}

void EXTI3_IRQHandler() {
    if (EXTI_GetITStatus(EXTI_Line3) != RESET) {
        EXTI_ClearITPendingBit(EXTI_Line3);
    }
}

void EXTI4_IRQHandler() {
    if (EXTI_GetITStatus(EXTI_Line4) != RESET) {
        EXTI_ClearITPendingBit(EXTI_Line4);
    }
}

void EXTI9_5_IRQHandler() {
    if (EXTI_GetITStatus(EXTI_Line5) != RESET) {
        EXTI_ClearITPendingBit(EXTI_Line5);
    }
    if (EXTI_GetITStatus(EXTI_Line6) != RESET) {
        EXTI_ClearITPendingBit(EXTI_Line6);
    }
    if (EXTI_GetITStatus(EXTI_Line7) != RESET) {
        EXTI_ClearITPendingBit(EXTI_Line7);
    }
    if (EXTI_GetITStatus(EXTI_Line8) != RESET) {
        EXTI_ClearITPendingBit(EXTI_Line8);
    }
    if (EXTI_GetITStatus(EXTI_Line9) != RESET) {
        EXTI_ClearITPendingBit(EXTI_Line9);
    }
}

void EXTI15_10_IRQHandler() {
}
