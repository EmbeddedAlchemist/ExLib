#include "ExLib_Buffer.hpp"

template <typename T>
void FIFOBuffer<T>::insertAfterWriteBlock() {
    if (currentBlockNum < maxBlockNum) {
        writeBlock->insertAfter(new SingleLinkableBuffer<T>(blockSize));
        currentBlockNum++;
    }
}

template <typename T>
FIFOBuffer<T>::FIFOBuffer(size_t blockSize, size_t maxBlockNum) : blockSize(blockSize), maxBlockNum(maxBlockNum) {
    readBlock = writeBlock = new SingleLinkableBuffer<T>(blockSize);
    readIndex = writeIndex = 0;
}

template <typename T>
T FIFOBuffer<T>::peek() {
    return T();
}

template <typename T>
T FIFOBuffer<T>::read() {
    if (readable()) {
        T ret = readBlock[readIndex];
        readIndex++;
        if (readIndex == blockSize) {
            SingleLinkableBuffer<T> *oldBlock = readBlock;
            readBlock = readBlock->next();
            delete oldBlock;
            currentBlockNum--;
        }
        return ret;
    } else {
        throw 1;
    }
}

template <typename T>
void FIFOBuffer<T>::write(T &data) {
    writeBlock[writeIndex] = data;
    writeIndex++;
    if (writeBlock->next() == nullptr && writeIndex >= blockSize / 2) {
        insertAfterWriteBlock();
    } else if (writeIndex == blockSize) {
        writeBlock = writeBlock->next();
        writeIndex = 0;
    }
}

template <typename T>
bool FIFOBuffer<T>::readable() {
    return (readBlock != writeBlock) || (readIndex != writeIndex);
}

template <typename T>
bool FIFOBuffer<T>::writeable() {
}
