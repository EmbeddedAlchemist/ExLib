#include "ExLib_Main.hpp"
#include "ExLib_Exception.hpp"
#include "ExLib_TimeAndDelay.hpp"

void ExLib_Init() {
    Time::_init();
}

int main() {
    try {
        ExLib_Init();
        ExLib_Main();
        throw ExLibException("ExLib_Main() Function has returned.");
    } catch (ExLibException e) {
    }
}