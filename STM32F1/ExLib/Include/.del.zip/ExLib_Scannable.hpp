#pragma once

#include <cstdint>
#include <string>

class Scannable {

  protected:
    virtual char readChar() = 0;
    virtual char peekChar(void) = 0;

  public:
    char peek(void);
    char read(void);
    char read(uint8_t buffer, size_t len);
    std::string &readLine(std::string &buf);
    char *readLine(char *buf, size_t len);
    char *readLine(char *buf);
    long long praseInt(void);
    double praseDouble(void);
    float praseFloat(void);

    Scannable &operator>>(long long &x);
    Scannable &operator>>(double &x);
    Scannable &operator>>(std::string &s);
    Scannable &operator>>(char *s);
};