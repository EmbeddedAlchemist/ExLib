#pragma once
#include <exception>

class CallbackFunctionException{
};

class CallbackFunction{
    protected:
      void (*callback)(void *);
      void *param;
    public:
      inline void call() { callback(param); };
      inline CallbackFunction() = delete;
      CallbackFunction(void (*callback)(void *), void *param) : callback(callback), param(param){};
      bool operator ==(CallbackFunction &f){
          return callback == callback && param == param;
      }
};