#include <cstdint>


struct SecondUnit;
struct MillisecondUnit;
struct MicrosecondUnit;

struct MillisecondUnit {
    uint32_t ms;
};

struct MicrosecondUnit {
    uint32_t us;
};

struct SecondUnit {
    uint32_t s;
};

SecondUnit operator"" _s(unsigned long long x);
MillisecondUnit operator"" _s(long double x);
MillisecondUnit operator"" _ms(unsigned long long x);
MicrosecondUnit operator"" _ms(long double x);
MicrosecondUnit operator"" _us(unsigned long long x);


class Time {
  private:
    static void _delayMs(uint32_t ms);
    static void _delayUs(uint32_t us);

  public:
    static volatile uint32_t _millisecond_value;

    static void _init();

    static uint32_t millisecond(void);
    static uint32_t microSecond(void);

    static void delayS(uint32_t s);
    static void delayMs(uint32_t ms);
    static void delayUs(uint32_t us);
    static inline void delayUs(MicrosecondUnit us) { delayUs(us.us); }
    static inline void delayMs(MillisecondUnit ms) { delayUs(ms.ms); }
    static inline void delayS(SecondUnit s) { delayUs(s.s); }
    static void inline delay(SecondUnit s) { delayS(s.s); }
    static void inline delay(MillisecondUnit ms) { delayMs(ms.ms); }
    static void inline delay(MicrosecondUnit us) { delayUs(us.us); }
};
