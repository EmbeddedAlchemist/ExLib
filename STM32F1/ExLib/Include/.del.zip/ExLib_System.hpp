#pragma once

#include "ExLib_Printable.hpp"

class System {
  private:
    static Printable *_debugInterface;

  public:
    static void debugInterface(Printable *itf);
    static void coreDump();
    static void reset();
    static void raiseHardFaultError();

};
