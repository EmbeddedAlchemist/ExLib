#pragma once

#include <exception>

class ExLibException : public std::exception {
  private:
    const char *msg;

  public:
    virtual const char *what(void) const noexcept override {
        return msg;
    }
    ExLibException(void) = delete;
    ExLibException(const char *msg) : msg(msg){};
};