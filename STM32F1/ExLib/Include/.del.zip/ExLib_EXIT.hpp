#pragma once
#include "ExLib_CallbackFunction.hpp"
#include "ExLib_GPIO.hpp"


enum class EXTITrigger : std::uint8_t {
    raising,
    falling,
    toggling
};


class EXTICallbackFunction : public CallbackFunction {
  protected:
    GPIO &io;
    EXTITrigger trigger;
    EXTICallbackFunction *next;
    static void callbackHandler(uint8_t);

  public:
    EXTICallbackFunction(void) = delete;
    EXTICallbackFunction(GPIO &io, EXTITrigger trigger, void (*callback)(void *), void *param);
    
    bool operator == (EXTICallbackFunction &f) {
        return CallbackFunction::operator==(f) && &io == &f.io && trigger == f.trigger;
    }
};

class EXTI{
  public:
    // EXTI(void) = delete;
    // void *operator new(size_t) = delete;
    // void operator delete(void *) = delete;

    static void init();
    static void registerCallback(EXTICallbackFunction &cb);
    static EXTICallbackFunction &unregisterCallback(EXTICallbackFunction &cb);
};