#pragma once

#include "ExLib_Buffer.hpp"
#include "ExLib_Exception.hpp"
#include "ExLib_GPIO.hpp"
#include "ExLib_Printable.hpp"
#include "ExLib_Scannable.hpp"

enum class UARTPeriph : uint8_t {
    UART1 = 0,
    UART2 = 1,
    UART3 = 2,
    UART4 = 3,
    UART5 = 4
};

enum class UARTParity : uint8_t {
    No,
    Even,
    Odd
};

enum class UARTStopBits : uint8_t {
    Bits0_5,
    Bits1,
    Bits1_5,
    Bits2
};

enum class UARTWordLength : uint8_t {
    Bits8 = 8,
    Bits9 = 9
};

class UARTException : public ExLibException {
  public:
    UARTException(const char *msg) : ExLibException(msg){};
};

class UART : public Scannable, Printable {
  private:
    FIFOBuffer<char> &txBuffer;
    FIFOBuffer<char> &rxBuffer;
    void *periph;

  public:
    UART(void) = delete;
    UART(UARTPeriph periph, size_t txBufferBlockSize = 64, size_t rxBufferSize = 64);
    ~UART();
    void begin(uint32_t BaudRate,
               UARTParity parity = UARTParity::No,
               UARTStopBits stopBits = UARTStopBits::Bits1, 
               UARTWordLength wordLength = UARTWordLength::Bits8);
    void end();
    void attach(GPIOPin txPin, GPIOPin rxPin);

    virtual void print(char c);
    virtual char read();
    virtual char peek();
    // using Printable::operator<<;
    // using Scannable::operator>>;
};