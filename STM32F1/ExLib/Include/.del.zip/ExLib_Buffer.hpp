#pragma once
#include <cstdint>
#include <cstddef>
template <typename T>
class PlainBuffer {
  private:
    size_t size;
    T buffer[];

  public:
    PlainBuffer() = delete;
    PlainBuffer(size_t size);
    PlainBuffer(T buffer[], size_t size) : buffer(buffer), size(size){};
    inline T operator[](size_t n) { return buffer[n]; }
};

template <typename T>
class SingleLinkableBuffer : public PlainBuffer<T> {
  private:
    PlainBuffer<T> *_next = nullptr;

  public:
    inline SingleLinkableBuffer<T> *next() { return _next; };
    void insertAfter(SingleLinkableBuffer *);
};


template <typename T>
class FIFOBuffer {
  private:
    size_t blockSize;
    const size_t maxBlockNum;
    size_t currentBlockNum;

    SingleLinkableBuffer<T> *readBlock;  // 指向下一个可读的块
    SingleLinkableBuffer<T> *writeBlock; // 指向下一个可写的块
    size_t readIndex;                    // 指向下一个可读的下标
    size_t writeIndex;                   // 指向下一个可写的下标

    void insertAfterWriteBlock();

  public:
    FIFOBuffer(void) = delete;
    FIFOBuffer(size_t blockSize, size_t maxBlockNum = 64);
    ~FIFOBuffer(void);

    T peek();
    T read();
    void write(T &data);
    bool readable();
    bool writeable();
    size_t dataSize();
    size_t blockNum();
};
