#pragma once

class Printable{
    virtual void write(char c);
}